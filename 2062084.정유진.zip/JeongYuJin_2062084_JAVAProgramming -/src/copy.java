import javax.swing.*;
import java.awt.*;

public class copy extends JFrame{
    public String getWriter() {
        return writer;
    }

    public String getBook() {
        return book;
    }

    public String getEssay() {
        return essay;
    }

    public String getTime() {
        return time;
    }

    private String writer, book, essay, time;
    JPanel panel1, panel2, panel3, panel4, panel5;
    JLabel bookLabel, writerLabel, timeLabel, txtLabel, label;
    public copy(String writer, String book, String essay,String time){
        this.writer=writer;
        this.book=book;
        this.essay=essay;
        this.time=time;
    }
    public void Line(){
        System.out.println("\t"+writer+"\t\t\t"+book+"\t\t\t"+time);
    }
    public void run(){
        Container c=getContentPane();
        c.setLayout(new FlowLayout());
        setTitle(book+"("+writer+")");
        panel1=new JPanel();
        panel2=new JPanel();
        panel3=new JPanel();
        panel4=new JPanel();
        panel5=new JPanel();

        bookLabel=new JLabel("제목 | "+book);
        writerLabel=new JLabel("이름 | "+writer);
        timeLabel=new JLabel("시간 | "+time);
        label=new JLabel("------------------------------------------------------------------------------------");
        txtLabel=new JLabel(essay);

        panel1.add(bookLabel);
        panel2.add(writerLabel);
        panel3.add(timeLabel);
        panel4.add(label);
        panel5.add(txtLabel);

        c.add(panel1);
        c.add(panel2);
        c.add(panel3);
        c.add(panel4);
        c.add(panel5);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(380,400);
        setVisible(true);
    }
}
