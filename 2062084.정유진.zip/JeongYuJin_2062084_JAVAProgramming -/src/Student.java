import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class Student extends JFrame implements ActionListener{
    private static String password;
    private static String Time;
    private static String BookName;
    private static String writer;
    private static String Essay;
    LocalDateTime localDateTime=LocalDateTime.now(ZoneId.of("Asia/Seoul"));
    JPanel noticePanel, namePanel, bookPanel, pwPanel, essayPanel;
    JLabel noticelabel, namelabel, booklabel, pwlabel, essaylabel;
    JPasswordField passwd;
    JTextField name, book;
    JTextArea essay;
    JButton submit;

    public void makeNew()  {
        Container c=getContentPane();
        c.setLayout(new FlowLayout());
        setTitle("독후감 쓰기");

        //알림
        noticePanel=new JPanel();
        noticelabel=new JLabel("*****작성 후 저장 버튼을 꼭 눌러주시기 바랍니다.*****");
        noticePanel.add(noticelabel);
        //이름
        namePanel=new JPanel();
        namelabel=new JLabel("작성자 이름 : ");
        name=new JTextField(10);
        namePanel.add(namelabel);
        namePanel.add(name);
        //책제목
        bookPanel=new JPanel();
        booklabel=new JLabel("읽은 책 제목 : ");
        book=new JTextField(10);
        bookPanel.add(booklabel);
        bookPanel.add(book);
        //에세이 작성
        essayPanel=new JPanel();
        essaylabel=new JLabel("독후감을 작성하세요 : ");
        essay=new JTextArea(10,20);
        essayPanel.add(essaylabel);
        essayPanel.add(essay);
        //비밀번호 설정
        pwPanel=new JPanel();
        pwlabel=new JLabel("게시글에 비밀번호를 설정하세요(숫자 제외 10자 이하) : ");
        passwd=new JPasswordField(10);
        pwPanel.add(pwlabel);
        pwPanel.add(passwd);
        //저장 버튼
        submit=new JButton("저장");
        pwPanel.add(submit);

        c.add(noticePanel);
        c.add(namePanel);
        c.add(bookPanel);
        c.add(essayPanel);
        c.add(pwPanel);

        submit.addActionListener(this);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(500,400);
        setVisible(true);

    }
    public void actionPerformed(ActionEvent e) {
        //이름
        writer=name.getText();
        //책 제목
        BookName=book.getText();
        //텍스트
        Essay=essay.getText();
        //비밀번호
        char[] pw=passwd.getPassword();
        password=String.valueOf(pw);
        //시간
        Time=localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

    }
    // getter*********************************************
    public String getPassword() {
        return password;
    }
    public String getBookName() {
        return BookName;
    }
    public String getWriter() {
        return writer;
    }
    public String getEssay() {
        return Essay;
    }
    public static String getTime() {
        return Time;
    }

}
