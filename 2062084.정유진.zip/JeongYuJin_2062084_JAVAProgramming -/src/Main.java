import java.util.*;

public class Main{
    static HashMap<String, copy> dic=new HashMap<String,copy>();
    static Scanner scanner=new Scanner(System.in);
    public static void prodMore(){
        Student newWrite=new Student();
        newWrite.makeNew();
        String pw= newWrite.getPassword();
        copy cpy=new copy(newWrite.getWriter(), newWrite.getBookName(), newWrite.getEssay(), newWrite.getTime());
        dic.put(pw,cpy);
    }

    public static void look(){
        Iterator<String> it=dic.keySet().iterator();

        System.out.println("\t\t\t\t\t\t<게시판>");
        System.out.println("==========================================================");

        if(!it.hasNext()){
            System.out.println("게시글이 없습니다");
        }
        while(it.hasNext()){
            String key=it.next();
            if(key==null){
                continue;
            }
            copy cc=dic.get(key);
            cc.Line();
        }
        System.out.println("==========================================================");
    }

    public static void main(String[] args) {
        int dal;

        //새 글을 추가해야만 직전에 추가한 글이 등록된다.
        while(true) {
            look();
            System.out.println(">>원하는 번호를 눌러주세요<<");
            System.out.print("글 추가(1)   내 글 보기(2)   나가기(3) : ");
            dal=scanner.nextInt();
            if(dal==3){
                System.out.println("[<프로그램을 종료합니다>]");
                break;
            }
            switch (dal){
                case 1:
                    System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                    prodMore();
                    break;
                case 2:
                    System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                    System.out.print("비밀번호를 입력해주세요 : ");
                    String tmp_pw=scanner.next();
                    if(dic.containsKey(tmp_pw)){
                        copy ff=dic.get(tmp_pw);
                        copy rr=new copy(ff.getWriter(),ff.getBook(), ff.getEssay(), ff.getTime());
                        rr.run();
                    }
                    else{
                        System.out.println("비밀번호가 맞지 않습니다.");
                    }
                    break;
                default:
                    System.out.println("!!잘못 입력하셨습니다.!!");
                    break;
            }
        }


    }
}